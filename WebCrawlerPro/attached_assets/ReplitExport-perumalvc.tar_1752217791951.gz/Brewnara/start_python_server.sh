#!/bin/bash
# Kill any existing processes
pkill -f "python.*main.py" || true
pkill -f "uvicorn" || true
pkill -f "node.*server" || true

# Wait a moment
sleep 2

# Start Python FastAPI server
echo "Starting Python FastAPI server..."
python main.py