# Brewnara - Coffee & Tea Social Platform

## Overview

Brewnara is a full-stack social media application designed for coffee and tea enthusiasts to share their experiences, discover new cafes, and connect with like-minded individuals. The platform allows users to create posts about their beverage experiences, including location, mood, and beverage details, while providing social features like likes and comments.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter for client-side routing
- **UI Components**: Shadcn/ui with Radix UI primitives
- **Styling**: Tailwind CSS with custom coffee/tea themed color palette
- **State Management**: TanStack Query (React Query) for server state
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Python 3.11 with FastAPI
- **Database ORM**: SQLAlchemy with PostgreSQL
- **Authentication**: JWT-based authentication with bcrypt password hashing
- **Session Management**: JWT tokens stored in localStorage
- **API**: RESTful API with JSON responses and automatic OpenAPI documentation

### Project Structure
```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Utility functions and configurations
│   │   └── pages/          # Route components
├── server/                 # Backend Node.js application (deprecated)
├── main.py                 # FastAPI application entry point
├── models.py               # SQLAlchemy database models
├── schemas.py              # Pydantic request/response schemas
├── auth.py                 # Authentication utilities and JWT handling
├── database.py             # Database connection and session management
├── shared/                 # Shared types and schemas
│   └── schema.ts          # Database schema and validation
└── migrations/            # Database migration files
```

## Key Components

### Database Schema
- **Users**: Profile information synchronized with Replit Auth
- **Posts**: User-generated content with beverage experiences
- **Comments**: Threaded discussions on posts
- **Likes**: Social engagement tracking
- **Sessions**: Secure session management

### Authentication System
- **Provider**: JWT-based authentication with local login/registration
- **Password Security**: bcrypt hashing with salt
- **Token Storage**: JWT access tokens stored in localStorage
- **Authorization**: Bearer token authentication with FastAPI dependencies
- **User Management**: Local user registration with password reset functionality

### Social Features
- **Post Creation**: Rich content with mood, beverage type, location, and experience tags
- **Engagement**: Like/unlike functionality with real-time counts
- **Comments**: Threaded comment system with user attribution
- **Discovery**: Feed-based content consumption

### User Interface
- **Responsive Design**: Mobile-first approach with desktop enhancements
- **Theme**: Custom coffee/tea inspired color palette
- **Navigation**: Sidebar for desktop, bottom navigation for mobile
- **Components**: Comprehensive UI component library with consistent styling

## Data Flow

### Authentication Flow
1. User accesses protected route
2. Middleware checks session validity
3. If unauthenticated, redirect to Replit Auth
4. On successful auth, create/update user record
5. Establish secure session

### Post Creation Flow
1. User submits post form with validation
2. Server validates data against schema
3. Post stored in database with user association
4. Client cache updated with new post
5. UI reflects changes immediately

### Social Interaction Flow
1. User performs action (like, comment)
2. Optimistic UI update for responsiveness
3. API request sent to server
4. Database updated with new state
5. Cache invalidation triggers data refetch

## External Dependencies

### Core Dependencies
- **fastapi**: Modern Python web framework
- **sqlalchemy**: Python SQL toolkit and ORM
- **psycopg2-binary**: PostgreSQL adapter for Python
- **uvicorn**: ASGI server for FastAPI
- **passlib[bcrypt]**: Password hashing library
- **python-jose**: JWT token handling
- **@tanstack/react-query**: Server state management
- **@radix-ui/**: Accessible UI primitives

### Development Tools
- **TypeScript**: Type safety across the stack
- **Vite**: Fast development and build tooling
- **Tailwind CSS**: Utility-first styling
- **ESBuild**: Production bundling

### Authentication
- **Replit Auth**: OAuth/OIDC identity provider
- **connect-pg-simple**: PostgreSQL session store
- **openid-client**: OIDC client implementation

## Deployment Strategy

### Development Environment
- **Hot Reload**: Vite development server with HMR
- **Database**: Neon PostgreSQL with connection pooling
- **Environment Variables**: Secure configuration management
- **Error Handling**: Development-friendly error overlays

### Production Build
- **Frontend**: Static assets built with Vite
- **Backend**: ESBuild bundling for Node.js deployment
- **Database Migrations**: Drizzle Kit for schema management
- **Session Security**: HTTP-only cookies with CSRF protection

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **SESSION_SECRET**: Secure session encryption key
- **REPLIT_DOMAINS**: Allowed authentication domains
- **ISSUER_URL**: OIDC provider endpoint

## Changelog
```
Changelog:
- July 04, 2025: Initial setup
- July 04, 2025: Replaced Replit Auth with custom authentication system including email/password login, Google OAuth, and GitHub OAuth support
- July 05, 2025: Implemented Google and GitHub OAuth login methods with automatic user creation
- July 05, 2025: Added comprehensive password reset functionality with secure token-based system
- July 11, 2025: Major architectural change - Converted entire backend from Node.js/Express to Python/FastAPI for easier maintenance and modification
```

## User Preferences
```
Preferred communication style: Simple, everyday language.
```