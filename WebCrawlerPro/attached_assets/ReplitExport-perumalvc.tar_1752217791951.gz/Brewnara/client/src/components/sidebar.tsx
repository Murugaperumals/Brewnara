import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";
import { 
  Home, 
  Compass, 
  MapPin, 
  UserCheck, 
  Bookmark, 
  User 
} from "lucide-react";

const navigation = [
  { name: "Home Feed", href: "/home", icon: Home, current: true },
  { name: "Discover", href: "/discover", icon: Compass, current: false },
  { name: "Nearby Brews", href: "/nearby", icon: MapPin, current: false },
  { name: "Following", href: "/following", icon: UserCheck, current: false },
  { name: "Saved Posts", href: "/saved", icon: Bookmark, current: false },
  { name: "My Profile", href: "/profile", icon: User, current: false },
];

export default function Sidebar() {
  const { user } = useAuth();

  return (
    <aside className="hidden lg:block w-64 p-6 bg-white h-screen sticky top-16 border-r border-latte-foam">
      <nav className="space-y-2">
        {navigation.map((item) => {
          const Icon = item.icon;
          return (
            <a
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors",
                item.current
                  ? "bg-espresso text-white"
                  : "text-gray-600 hover:bg-warm-cream"
              )}
            >
              <Icon className="w-5 h-5" />
              <span>{item.name}</span>
            </a>
          );
        })}
      </nav>

      {/* Quick Stats */}
      <div className="mt-8 p-4 bg-warm-cream rounded-lg">
        <h3 className="font-semibold text-coffee-bean mb-3">Your Journey</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">Posts shared</span>
            <span className="font-medium text-espresso">0</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Cafes visited</span>
            <span className="font-medium text-espresso">0</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Followers</span>
            <span className="font-medium text-espresso">0</span>
          </div>
        </div>
      </div>
    </aside>
  );
}
