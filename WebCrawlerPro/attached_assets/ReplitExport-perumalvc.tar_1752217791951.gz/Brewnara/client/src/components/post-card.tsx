import { useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import type { PostWithUser, CommentWithUser } from "@shared/schema";
import { 
  Heart, 
  MessageCircle, 
  Share, 
  Bookmark, 
  MapPin, 
  MoreHorizontal,
  User,
  Coffee,
  Smile,
  Star,
  Leaf
} from "lucide-react";

interface PostCardProps {
  post: PostWithUser;
}

const getMoodEmoji = (mood: string | null) => {
  const moodMap: Record<string, string> = {
    energized: "⚡",
    peaceful: "🧘",
    focused: "🎯",
    happy: "😊",
    relaxed: "😌",
    inspired: "✨",
  };
  return mood ? moodMap[mood] || "😊" : "";
};

const getBeverageIcon = (beverage: string | null) => {
  if (!beverage) return null;
  return beverage.includes("tea") ? "🍃" : "☕";
};

const getExperienceIcon = (experience: string | null) => {
  const experienceMap: Record<string, string> = {
    "first-visit": "⭐",
    "regular-spot": "🏠",
    "work-session": "💻",
    "date": "💕",
    "meeting": "🤝",
    "solo-time": "🧘",
    "afternoon-ritual": "🕐",
    "morning-routine": "🌅",
  };
  return experience ? experienceMap[experience] || "✨" : "";
};

export default function PostCard({ post }: PostCardProps) {
  const [isLiked, setIsLiked] = useState(post.isLiked);
  const [likesCount, setLikesCount] = useState(post.likesCount);
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState("");

  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: comments = [] } = useQuery<CommentWithUser[]>({
    queryKey: ["/api/posts", post.id, "comments"],
    enabled: showComments,
  });

  const likeMutation = useMutation({
    mutationFn: async () => {
      await apiRequest(`/api/posts/${post.id}/like`, "POST");
    },
    onSuccess: () => {
      setIsLiked(!isLiked);
      setLikesCount(isLiked ? likesCount - 1 : likesCount + 1);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to like post. Please try again.",
        variant: "destructive",
      });
    },
  });

  const commentMutation = useMutation({
    mutationFn: async (content: string) => {
      await apiRequest(`/api/posts/${post.id}/comments`, "POST", { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts", post.id, "comments"] });
      setNewComment("");
      toast({
        title: "Success",
        description: "Comment added!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add comment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleLike = () => {
    likeMutation.mutate();
  };

  const handleComment = () => {
    if (!newComment.trim()) return;
    commentMutation.mutate(newComment);
  };

  const formatLabel = (value: string) => {
    return value.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  return (
    <Card className="border-latte-foam overflow-hidden hover:shadow-lg transition-all duration-200 hover:border-espresso group">
      {/* Post Header */}
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            {post.user.profileImageUrl ? (
              <img
                src={post.user.profileImageUrl}
                alt={`${post.user.firstName || post.user.email} profile`}
                className="w-10 h-10 rounded-full object-cover border-2 border-transparent group-hover:border-latte-foam transition-all duration-200 cursor-pointer"
              />
            ) : (
              <div className="w-10 h-10 bg-espresso rounded-full flex items-center justify-center border-2 border-transparent group-hover:border-latte-foam transition-all duration-200 cursor-pointer">
                <User className="w-5 h-5 text-white" />
              </div>
            )}
            <div>
              <h3 className="font-semibold text-coffee-bean group-hover:text-espresso transition-colors cursor-pointer">
                {post.user.firstName ? `${post.user.firstName} ${post.user.lastName || ''}` : post.user.email}
              </h3>
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                {post.location && (
                  <>
                    <MapPin className="w-3 h-3 text-chai-orange" />
                    <span className="hover:text-espresso transition-colors cursor-pointer">{post.location}</span>
                    <span>•</span>
                  </>
                )}
                <span>{formatDistanceToNow(new Date(post.createdAt))} ago</span>
              </div>
            </div>
          </div>
          <Button variant="ghost" size="sm">
            <MoreHorizontal className="w-4 h-4 text-gray-400" />
          </Button>
        </div>

        {/* Post Image */}
        {post.imageUrl && (
          <img
            src={post.imageUrl}
            alt="Post content"
            className="w-full h-80 object-cover rounded-lg mb-4"
          />
        )}

        {/* Post Content */}
        <div>
          {/* Tags */}
          {(post.mood || post.beverage || post.experience) && (
            <div className="flex flex-wrap gap-2 mb-3">
              {post.mood && (
                <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 border-yellow-200">
                  <Smile className="w-3 h-3 mr-1" />
                  {getMoodEmoji(post.mood)} {formatLabel(post.mood)}
                </Badge>
              )}
              {post.beverage && (
                <Badge variant="secondary" className="bg-blue-100 text-blue-800 border-blue-200">
                  <Coffee className="w-3 h-3 mr-1" />
                  {getBeverageIcon(post.beverage)} {formatLabel(post.beverage)}
                </Badge>
              )}
              {post.experience && (
                <Badge variant="secondary" className="bg-green-100 text-green-800 border-green-200">
                  <Star className="w-3 h-3 mr-1" />
                  {getExperienceIcon(post.experience)} {formatLabel(post.experience)}
                </Badge>
              )}
            </div>
          )}

          <p className="text-gray-800 mb-4">{post.content}</p>

          {/* Post Actions */}
          <div className="flex items-center justify-between pt-3 border-t border-latte-foam">
            <div className="flex space-x-6">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLike}
                disabled={likeMutation.isPending}
                className={`flex items-center space-x-2 transition-all duration-200 hover:scale-105 ${
                  isLiked ? "text-red-500" : "text-gray-600 hover:text-red-500"
                }`}
              >
                <Heart className={`w-4 h-4 transition-all duration-200 ${isLiked ? "fill-current scale-110" : ""}`} />
                <span className="text-sm font-medium">{likesCount}</span>
              </Button>
              
              <Dialog open={showComments} onOpenChange={setShowComments}>
                <DialogTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex items-center space-x-2 text-gray-600 hover:text-espresso transition-all duration-200 hover:scale-105"
                  >
                    {post.beverage && post.beverage.includes("tea") ? (
                      <Leaf className="w-4 h-4 transition-all duration-200" />
                    ) : (
                      <Coffee className="w-4 h-4 transition-all duration-200" />
                    )}
                    <span className="text-sm font-medium">{post.commentsCount}</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-lg max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Comments</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    {/* Comments List */}
                    <div className="space-y-3 max-h-60 overflow-y-auto">
                      {comments.length === 0 ? (
                        <div className="text-center py-8 text-gray-500">
                          <div className="mb-4">
                            {post.beverage && post.beverage.includes("tea") ? (
                              <Leaf className="w-12 h-12 mx-auto text-gray-300" />
                            ) : (
                              <Coffee className="w-12 h-12 mx-auto text-gray-300" />
                            )}
                          </div>
                          <h3 className="text-sm font-medium text-coffee-bean mb-1">No comments yet</h3>
                          <p className="text-xs text-gray-500">Be the first to share your thoughts about this {post.beverage || 'beverage'} experience!</p>
                          <div className="mt-3 text-xs text-gray-400">
                            💭 Share your brewing tips • ⭐ Rate the experience • 🗺️ Recommend similar places
                          </div>
                        </div>
                      ) : (
                        <>
                          {comments
                            .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                            .map((comment) => (
                            <div key={comment.id} className="flex items-start space-x-2 hover:bg-gray-50 p-2 rounded">
                              {comment.user.profileImageUrl ? (
                                <img
                                  src={comment.user.profileImageUrl}
                                  alt={`${comment.user.firstName || comment.user.email} profile`}
                                  className="w-6 h-6 rounded-full object-cover"
                                />
                              ) : (
                                <div className="w-6 h-6 bg-espresso rounded-full flex items-center justify-center">
                                  <User className="w-3 h-3 text-white" />
                                </div>
                              )}
                              <div className="flex-1">
                                <div className="flex items-center space-x-2">
                                  <span className="font-medium text-sm text-coffee-bean">
                                    {comment.user.firstName ? `${comment.user.firstName} ${comment.user.lastName || ''}` : comment.user.email}
                                  </span>
                                  <span className="text-xs text-gray-400">
                                    {formatDistanceToNow(new Date(comment.createdAt))} ago
                                  </span>
                                </div>
                                <p className="text-sm text-gray-600 mt-1">{comment.content}</p>
                                <div className="flex items-center space-x-4 mt-2">
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="text-xs text-gray-500 hover:text-espresso p-0 h-auto transition-colors"
                                    onClick={() => {
                                      // Focus on the comment input for reply
                                      const commentInput = document.querySelector('textarea[placeholder*="Write a comment"]') as HTMLTextAreaElement;
                                      if (commentInput) {
                                        commentInput.focus();
                                        commentInput.value = `@${comment.user.firstName || comment.user.email.split('@')[0]} `;
                                        setNewComment(commentInput.value);
                                      }
                                    }}
                                  >
                                    Reply
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="text-xs text-gray-500 hover:text-red-500 p-0 h-auto transition-colors flex items-center"
                                    onClick={() => {
                                      toast({
                                        title: "Coming Soon",
                                        description: "Comment likes will be available soon!",
                                      });
                                    }}
                                  >
                                    <Heart className="w-3 h-3 mr-1" />
                                    Like
                                  </Button>
                                </div>
                              </div>
                            </div>
                          ))}
                          {comments.length > 3 && (
                            <div className="text-center">
                              <Button variant="link" size="sm" className="text-espresso text-xs">
                                View all {comments.length} comments
                              </Button>
                            </div>
                          )}
                        </>
                      )}
                    </div>

                    {/* Add Comment */}
                    <div className="space-y-2 border-t border-latte-foam pt-3">
                      <Label htmlFor="comment" className="text-coffee-bean font-medium">Add a comment</Label>
                      <Textarea
                        id="comment"
                        placeholder={`Share your thoughts about this ${post.beverage || 'beverage'} experience...`}
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        className="min-h-[80px] border-latte-foam focus:border-espresso resize-none"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                            e.preventDefault();
                            if (newComment.trim()) {
                              handleComment();
                            }
                          }
                        }}
                      />
                      <div className="flex justify-between items-center">
                        <p className="text-xs text-gray-500">
                          Press Cmd+Enter to submit
                        </p>
                        <Button
                          onClick={handleComment}
                          disabled={commentMutation.isPending || !newComment.trim()}
                          size="sm"
                          className="bg-espresso hover:bg-coffee-bean text-white disabled:opacity-50 transition-all"
                        >
                          {commentMutation.isPending ? "Adding..." : "Comment"}
                        </Button>
                      </div>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              
              <Button
                variant="ghost"
                size="sm"
                className="flex items-center space-x-2 text-gray-600 hover:text-espresso transition-colors"
              >
                <Share className="w-4 h-4" />
                <span className="text-sm">Share</span>
              </Button>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="text-gray-600 hover:text-espresso transition-colors"
            >
              <Bookmark className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
