import { useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import type { PostWithUser, CommentWithUser } from "@shared/schema";
import {
  Heart,
  MessageCircle,
  Share,
  Bookmark,
  MapPin,
  MoreHorizontal,
  User,
  Coffee,
  Smile,
  Star,
  Leaf,
} from "lucide-react";

interface PostCardProps {
  post: PostWithUser;
}

const getMoodEmoji = (mood: string | null) => {
  const moodMap: Record<string, string> = {
    energized: "⚡",
    peaceful: "🧘",
    focused: "🎯",
    happy: "😊",
    relaxed: "😌",
    inspired: "✨",
  };
  return mood ? moodMap[mood] || "😊" : "";
};

const getBeverageIcon = (beverage: string | null) => {
  if (!beverage) return null;
  return beverage.includes("tea") ? "🍃" : "☕";
};

const getExperienceIcon = (experience: string | null) => {
  const experienceMap: Record<string, string> = {
    "first-visit": "⭐",
    "regular-spot": "🏠",
    "work-session": "💻",
    date: "💕",
    meeting: "🤝",
    "solo-time": "🧘",
    "afternoon-ritual": "🕐",
    "morning-routine": "🌅",
  };
  return experience ? experienceMap[experience] || "✨" : "";
};

// Helper function to build a nested comment tree
const buildCommentTree = (comments: CommentWithUser[]) => {
  const commentMap: Record<number, CommentWithUser> = {};
  const rootComments: CommentWithUser[] = [];

  comments.forEach((comment) => {
    commentMap[comment.id] = { ...comment, replies: [] };
  });

  comments.forEach((comment) => {
    if (comment.parentId !== null && commentMap[comment.parentId]) {
      commentMap[comment.parentId].replies!.push(commentMap[comment.id]);
    } else {
      rootComments.push(commentMap[comment.id]);
    }
  });

  return rootComments;
};

// Recursive component to render comments and their replies
const CommentItem: React.FC<{ comment: CommentWithUser; postId: number }> = ({
  comment,
  postId,
}) => {
  const [showReplyInput, setShowReplyInput] = useState(false);
  const [replyContent, setReplyContent] = useState("");
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const replyMutation = useMutation({
    mutationFn: async ({
      content,
      parentId,
    }: {
      content: string;
      parentId: number;
    }) => {
      const response = await apiRequest(
        `/api/posts/${postId}/comments`,
        "POST",
        {
          content,
          parentId,
        }
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/comments", postId],
      });
      setReplyContent("");
      setShowReplyInput(false);
      toast({
        title: "Success",
        description: "Reply added!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add reply. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleReplySubmit = () => {
    if (!replyContent.trim()) return;
    replyMutation.mutate({ content: replyContent, parentId: comment.id });
  };

  return (
    <div className="space-y-2 ml-4 border-l pl-4">
      <div className="flex items-start space-x-2 hover:bg-gray-50 p-2 rounded">
        {comment.user.profileImageUrl ? (
          <img
            src={comment.user.profileImageUrl}
            alt={`${comment.user.firstName || comment.user.email} profile`}
            className="w-6 h-6 rounded-full object-cover"
          />
        ) : (
          <div className="w-6 h-6 bg-espresso rounded-full flex items-center justify-center">
            <User className="w-3 h-3 text-white" />
          </div>
        )}
        <div className="flex-1">
          <div className="flex items-center space-x-2">
            <span className="font-medium text-sm text-coffee-bean">
              {comment.user.firstName
                ? `${comment.user.firstName} ${comment.user.lastName || ""}`
                : comment.user.email}
            </span>
            <span className="text-xs text-gray-400">
              {formatDistanceToNow(new Date(comment.createdAt))} ago
            </span>
          </div>
          <p className="text-sm text-gray-600 mt-1">{comment.content}</p>
          <div className="flex items-center space-x-4 mt-2">
            <Button
              variant="ghost"
              size="sm"
              className="text-xs text-gray-500 hover:text-espresso p-0 h-auto transition-colors"
              onClick={() => setShowReplyInput(!showReplyInput)}
            >
              Reply
            </Button>
            {/* Comment Like Button (Placeholder) */}
            <Button
              variant="ghost"
              size="sm"
              className="text-xs text-gray-500 hover:text-red-500 p-0 h-auto transition-colors flex items-center"
              onClick={() => {
                toast({
                  title: "Coming Soon",
                  description: "Comment likes will be available soon!",
                });
              }}
            >
              <Heart className="w-3 h-3 mr-1" />
              Like
            </Button>
          </div>

          {/* Reply Input */}
          {showReplyInput && (
            <div className="mt-2 space-y-2">
              <Label htmlFor={`reply-${comment.id}`} className="sr-only">
                Add a reply
              </Label>
              <Textarea
                id={`reply-${comment.id}`}
                placeholder={`Reply to ${
                  comment.user.firstName || comment.user.email?.split("@")[0]
                }...`}
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                className="min-h-[40px] border-latte-foam focus:border-espresso resize-none text-sm"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                    e.preventDefault();
                    if (replyContent.trim()) {
                      handleReplySubmit();
                    }
                  }
                }}
              />
              <div className="flex justify-end">
                <Button
                  onClick={handleReplySubmit}
                  disabled={replyMutation.isPending || !replyContent.trim()}
                  size="sm"
                  className="bg-espresso hover:bg-espresso/90 text-white"
                >
                  {replyMutation.isPending ? "Posting..." : "Post Reply"}
                </Button>
              </div>
            </div>
          )}
        </div>
      );
    };

function FacebookStylePostCard({ post }: PostCardProps) {
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState("");
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: comments = [] } = useQuery({
    queryKey: ["/api/comments", post.id],
    enabled: showComments,
  });

  const likeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest(
        `/api/posts/${post.id}/like`,
        "POST",
        {},
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/posts"],
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Authentication Required",
          description: "Please log in to like posts",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Failed to toggle like",
          variant: "destructive",
        });
      }
    },
  });

  const commentMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest(
        `/api/posts/${post.id}/comments`,
        "POST",
        { content },
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/comments", post.id],
      });
      setNewComment("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Authentication Required",
          description: "Please log in to comment",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Failed to post comment",
          variant: "destructive",
        });
      }
    },
  });

  const handleSubmitComment = () => {
    if (newComment.trim()) {
      commentMutation.mutate(newComment);
    }
  };

  const handleLike = () => {
    likeMutation.mutate();
  };

  const commentTree = buildCommentTree(comments);

  return (
    <Card className="w-full max-w-2xl mx-auto mb-6 shadow-lg border-latte-foam">
      <CardContent className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-mocha-cream rounded-full flex items-center justify-center">
              <User className="w-6 h-6 text-espresso" />
            </div>
            <div>
              <h3 className="font-semibold text-espresso">
                {post.user.firstName || post.user.email?.split("@")[0] || "Anonymous"}
              </h3>
              <p className="text-sm text-gray-500">
                {formatDistanceToNow(new Date(post.createdAt), {
                  addSuffix: true,
                })}
              </p>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-espresso">
            <MoreHorizontal className="w-5 h-5" />
          </Button>
        </div>

        {/* Post Content */}
        <div className="mb-4">
          <p className="text-gray-800 mb-3">{post.content}</p>
          
          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-3">
            {post.mood && (
              <Badge
                variant="secondary"
                className="bg-mocha-cream text-espresso hover:bg-mocha-cream/80"
              >
                <Smile className="w-3 h-3 mr-1" />
                {getMoodEmoji(post.mood)} {post.mood}
              </Badge>
            )}
            {post.beverage && (
              <Badge
                variant="secondary"
                className="bg-sage-green text-white hover:bg-sage-green/80"
              >
                <Coffee className="w-3 h-3 mr-1" />
                {getBeverageIcon(post.beverage)} {post.beverage}
              </Badge>
            )}
            {post.experience && (
              <Badge
                variant="secondary"
                className="bg-cinnamon-spice text-white hover:bg-cinnamon-spice/80"
              >
                <Star className="w-3 h-3 mr-1" />
                {getExperienceIcon(post.experience)} {post.experience.replace("-", " ")}
              </Badge>
            )}
          </div>

          {/* Location */}
          {post.location && (
            <div className="flex items-center text-sm text-gray-600 mb-3">
              <MapPin className="w-4 h-4 mr-1" />
              {post.location}
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-3 border-t border-latte-foam">
          <div className="flex items-center space-x-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLike}
              disabled={likeMutation.isPending}
              className={`flex items-center space-x-2 transition-colors ${
                post.isLiked
                  ? "text-red-500 hover:text-red-600"
                  : "text-gray-500 hover:text-red-500"
              }`}
            >
              <Heart
                className={`w-5 h-5 ${post.isLiked ? "fill-current" : ""}`}
              />
              <span>Like</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowComments(!showComments)}
              className="flex items-center space-x-2 text-gray-500 hover:text-espresso transition-colors"
            >
              <MessageCircle className="w-5 h-5" />
              <span>Comment</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-2 text-gray-500 hover:text-espresso transition-colors"
            >
              <Share className="w-5 h-5" />
              <span>Share</span>
            </Button>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-gray-500 hover:text-espresso transition-colors"
          >
            <Bookmark className="w-5 h-5" />
          </Button>
        </div>

        {/* Comments Section */}
        {showComments && (
          <div className="mt-4 pt-4 border-t border-latte-foam">
            {/* Comment Input */}
            <div className="mb-4">
              <div className="flex space-x-3">
                <div className="w-8 h-8 bg-mocha-cream rounded-full flex items-center justify-center flex-shrink-0">
                  <User className="w-4 h-4 text-espresso" />
                </div>
                <div className="flex-1">
                  <Label htmlFor="comment" className="sr-only">
                    Add a comment
                  </Label>
                  <Textarea
                    id="comment"
                    placeholder="Write a comment..."
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    className="min-h-[80px] border-latte-foam focus:border-espresso resize-none"
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                        e.preventDefault();
                        handleSubmitComment();
                      }
                    }}
                  />
                  <div className="flex justify-end mt-2">
                    <Button
                      onClick={handleSubmitComment}
                      disabled={commentMutation.isPending || !newComment.trim()}
                      size="sm"
                      className="bg-espresso hover:bg-espresso/90 text-white"
                    >
                      {commentMutation.isPending ? "Posting..." : "Post Comment"}
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Comments List */}
            <div className="space-y-4">
              {commentTree.map((comment) => (
                <CommentItem key={comment.id} comment={comment} postId={post.id} />
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default FacebookStylePostCard;
