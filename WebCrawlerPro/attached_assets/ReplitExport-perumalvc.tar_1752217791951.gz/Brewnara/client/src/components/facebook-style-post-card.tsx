import { useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import type { PostWithUser, CommentWithUser } from "@shared/schema";
import {
  Heart,
  MessageCircle,
  Share,
  Bookmark,
  MapPin,
  MoreHorizontal,
  User,
  Coffee,
  Smile,
  Star,
} from "lucide-react";

interface PostCardProps {
  post: PostWithUser;
}

const getMoodEmoji = (mood: string | null) => {
  const moodMap: Record<string, string> = {
    energized: "⚡",
    peaceful: "🧘",
    focused: "🎯",
    happy: "😊",
    relaxed: "😌",
    inspired: "✨",
  };
  return mood ? moodMap[mood] || "😊" : "";
};

const getBeverageIcon = (beverage: string | null) => {
  if (!beverage) return null;
  return beverage.includes("tea") ? "🍃" : "☕";
};

const getExperienceIcon = (experience: string | null) => {
  const experienceMap: Record<string, string> = {
    "first-visit": "⭐",
    "regular-spot": "🏠",
    "work-session": "💻",
    date: "💕",
    meeting: "🤝",
    "solo-time": "🧘",
    "afternoon-ritual": "🕐",
    "morning-routine": "🌅",
  };
  return experience ? experienceMap[experience] || "✨" : "";
};

export default function FacebookStylePostCard({ post }: PostCardProps) {
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState("");
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: comments = [] } = useQuery({
    queryKey: ["/api/comments", post.id],
    enabled: showComments,
  });

  const likeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest(
        `/api/posts/${post.id}/like`,
        "POST",
        {},
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/posts"],
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Authentication Required",
          description: "Please log in to like posts",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Failed to toggle like",
          variant: "destructive",
        });
      }
    },
  });

  const commentMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest(
        `/api/posts/${post.id}/comments`,
        "POST",
        { content },
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/comments", post.id],
      });
      setNewComment("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Authentication Required",
          description: "Please log in to comment",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Failed to post comment",
          variant: "destructive",
        });
      }
    },
  });

  const handleSubmitComment = () => {
    if (newComment.trim()) {
      commentMutation.mutate(newComment);
    }
  };

  const handleLike = () => {
    likeMutation.mutate();
  };

  return (
    <Card className="w-full max-w-2xl mx-auto mb-6 shadow-lg border-latte-foam">
      <CardContent className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-mocha-cream rounded-full flex items-center justify-center">
              <User className="w-6 h-6 text-espresso" />
            </div>
            <div>
              <h3 className="font-semibold text-espresso">
                {post.user.firstName || post.user.email?.split("@")[0] || "Anonymous"}
              </h3>
              <p className="text-sm text-gray-500">
                {formatDistanceToNow(new Date(post.createdAt), {
                  addSuffix: true,
                })}
              </p>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-espresso">
            <MoreHorizontal className="w-5 h-5" />
          </Button>
        </div>

        {/* Post Content */}
        <div className="mb-4">
          <p className="text-gray-800 mb-3">{post.content}</p>
          
          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-3">
            {post.mood && (
              <Badge
                variant="secondary"
                className="bg-mocha-cream text-espresso hover:bg-mocha-cream/80"
              >
                <Smile className="w-3 h-3 mr-1" />
                {getMoodEmoji(post.mood)} {post.mood}
              </Badge>
            )}
            {post.beverage && (
              <Badge
                variant="secondary"
                className="bg-sage-green text-white hover:bg-sage-green/80"
              >
                <Coffee className="w-3 h-3 mr-1" />
                {getBeverageIcon(post.beverage)} {post.beverage}
              </Badge>
            )}
            {post.experience && (
              <Badge
                variant="secondary"
                className="bg-cinnamon-spice text-white hover:bg-cinnamon-spice/80"
              >
                <Star className="w-3 h-3 mr-1" />
                {getExperienceIcon(post.experience)} {post.experience.replace("-", " ")}
              </Badge>
            )}
          </div>

          {/* Location */}
          {post.location && (
            <div className="flex items-center text-sm text-gray-600 mb-3">
              <MapPin className="w-4 h-4 mr-1" />
              {post.location}
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-3 border-t border-latte-foam">
          <div className="flex items-center space-x-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLike}
              disabled={likeMutation.isPending}
              className={`flex items-center space-x-2 transition-colors ${
                post.isLiked
                  ? "text-red-500 hover:text-red-600"
                  : "text-gray-500 hover:text-red-500"
              }`}
            >
              <Heart
                className={`w-5 h-5 ${post.isLiked ? "fill-current" : ""}`}
              />
              <span>Like</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowComments(!showComments)}
              className="flex items-center space-x-2 text-gray-500 hover:text-espresso transition-colors"
            >
              <MessageCircle className="w-5 h-5" />
              <span>Comment</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-2 text-gray-500 hover:text-espresso transition-colors"
            >
              <Share className="w-5 h-5" />
              <span>Share</span>
            </Button>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-gray-500 hover:text-espresso transition-colors"
          >
            <Bookmark className="w-5 h-5" />
          </Button>
        </div>

        {/* Comments Section */}
        {showComments && (
          <div className="mt-4 pt-4 border-t border-latte-foam">
            {/* Comment Input */}
            <div className="mb-4">
              <div className="flex space-x-3">
                <div className="w-8 h-8 bg-mocha-cream rounded-full flex items-center justify-center flex-shrink-0">
                  <User className="w-4 h-4 text-espresso" />
                </div>
                <div className="flex-1">
                  <Label htmlFor="comment" className="sr-only">
                    Add a comment
                  </Label>
                  <Textarea
                    id="comment"
                    placeholder="Write a comment..."
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    className="min-h-[80px] border-latte-foam focus:border-espresso resize-none"
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                        e.preventDefault();
                        handleSubmitComment();
                      }
                    }}
                  />
                  <div className="flex justify-end mt-2">
                    <Button
                      onClick={handleSubmitComment}
                      disabled={commentMutation.isPending || !newComment.trim()}
                      size="sm"
                      className="bg-espresso hover:bg-espresso/90 text-white"
                    >
                      {commentMutation.isPending ? "Posting..." : "Post Comment"}
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Comments List */}
            <div className="space-y-4">
              {comments.map((comment: CommentWithUser) => (
                <div key={comment.id} className="flex items-start space-x-2">
                  <div className="w-8 h-8 bg-mocha-cream rounded-full flex items-center justify-center flex-shrink-0">
                    <User className="w-4 h-4 text-espresso" />
                  </div>
                  <div className="flex-1">
                    <div className="bg-gray-50 rounded-lg p-3">
                      <div className="font-medium text-sm text-espresso mb-1">
                        {comment.user.firstName || comment.user.email?.split("@")[0] || "Anonymous"}
                      </div>
                      <div className="text-sm text-gray-800">
                        {comment.content}
                      </div>
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      {formatDistanceToNow(new Date(comment.createdAt), {
                        addSuffix: true,
                      })}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}