import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, 
  UserPlus, 
  Trophy, 
  ChevronRight,
  User,
  MapPin,
  Coffee,
  Wifi
} from "lucide-react";

const trendingLocations = [
  { name: "Blue Bottle Coffee", posts: 142 },
  { name: "Ritual Coffee", posts: 89 },
  { name: "Philz Coffee", posts: 67 },
];

const suggestedUsers = [
  { 
    name: "Emma Wilson", 
    info: "3 mutual connections",
    location: "0.2 miles away",
    status: "online",
    interests: ["Coffee", "Latte Art"],
    profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=32&h=32"
  },
  { 
    name: "Maria Santos", 
    info: "Coffee enthusiast",
    location: "0.8 miles away", 
    status: "recently_active",
    interests: ["Tea", "Brewing"],
    profileImage: "https://images.unsplash.com/photo-1527980965255-d3b416303d12?ixlib=rb-4.0.3&auto=format&fit=crop&w=32&h=32"
  },
];

export default function RightSidebar() {
  return (
    <aside className="hidden xl:block w-80 p-6 bg-white h-screen sticky top-16 border-l border-latte-foam overflow-y-auto">
      {/* Trending Locations */}
      <Card className="mb-6 border-latte-foam">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center text-coffee-bean">
            <TrendingUp className="w-5 h-5 text-chai-orange mr-2" />
            Trending Locations
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {trendingLocations.map((location, index) => (
            <div
              key={index}
              className="group flex items-center justify-between p-3 hover:bg-warm-cream rounded-lg cursor-pointer transition-all duration-200 border border-transparent hover:border-latte-foam hover:shadow-sm"
            >
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200 group-hover:scale-110 ${
                  index === 0 ? 'bg-yellow-100 text-yellow-700 group-hover:bg-yellow-200' : 
                  index === 1 ? 'bg-blue-100 text-blue-700 group-hover:bg-blue-200' : 
                  'bg-green-100 text-green-700 group-hover:bg-green-200'
                }`}>
                  <span className="text-sm font-bold">#{index + 1}</span>
                </div>
                <div>
                  <p className="font-medium text-coffee-bean group-hover:text-espresso transition-colors">{location.name}</p>
                  <div className="flex items-center space-x-2">
                    <p className="text-sm text-gray-500">{location.posts} posts today</p>
                    <div className="w-1 h-1 bg-gray-300 rounded-full"></div>
                    <p className="text-xs text-green-600 group-hover:text-green-700 transition-colors">🔥 Trending</p>
                  </div>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-espresso transition-all duration-200 group-hover:translate-x-1" />
            </div>
          ))}
          <div className="text-center pt-2 border-t border-latte-foam">
            <Button variant="link" size="sm" className="text-espresso hover:text-coffee-bean text-xs p-0 h-auto hover:underline transition-all">
              Discover more locations
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Suggested Users */}
      <Card className="mb-6 border-latte-foam">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center text-coffee-bean">
            <UserPlus className="w-5 h-5 text-tea-green mr-2" />
            Suggested for You
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {suggestedUsers.map((user, index) => (
            <div key={index} className="group p-3 hover:bg-warm-cream rounded-lg transition-all duration-200 hover:shadow-md border border-transparent hover:border-latte-foam cursor-pointer">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3 flex-1">
                  <div className="relative">
                    {user.profileImage ? (
                      <img
                        src={user.profileImage}
                        alt={`${user.name} profile`}
                        className="w-12 h-12 rounded-full object-cover border-2 border-latte-foam group-hover:border-espresso transition-colors"
                      />
                    ) : (
                      <div className="w-12 h-12 bg-espresso rounded-full flex items-center justify-center border-2 border-latte-foam group-hover:border-coffee-bean transition-colors">
                        <User className="w-6 h-6 text-white" />
                      </div>
                    )}
                    {/* Online status indicator */}
                    <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${
                      user.status === 'online' ? 'bg-green-500' : 
                      user.status === 'recently_active' ? 'bg-yellow-500' : 'bg-gray-400'
                    }`}></div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2">
                      <p className="font-medium text-coffee-bean text-sm truncate">{user.name}</p>
                      {user.status === 'online' && (
                        <Wifi className="w-3 h-3 text-green-500" />
                      )}
                    </div>
                    
                    <p className="text-xs text-gray-500 mb-1">{user.info}</p>
                    
                    {/* Location indicator */}
                    <div className="flex items-center space-x-1 mb-2">
                      <MapPin className="w-3 h-3 text-gray-400" />
                      <span className="text-xs text-gray-600">{user.location}</span>
                    </div>
                    
                    {/* Interests */}
                    <div className="flex items-center space-x-1 flex-wrap">
                      {user.interests.map((interest, idx) => (
                        <div key={idx} className="flex items-center space-x-1">
                          <Coffee className="w-3 h-3 text-chai-orange" />
                          <span className="text-xs text-chai-orange font-medium">{interest}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                <Button 
                  size="sm" 
                  className="text-xs px-4 py-2 bg-espresso text-white rounded-full hover:bg-coffee-bean transition-all duration-200 shadow-sm hover:shadow-md group-hover:scale-105"
                >
                  Follow
                </Button>
              </div>
            </div>
          ))}
          <div className="text-center pt-2 border-t border-latte-foam">
            <Button variant="link" size="sm" className="text-espresso hover:text-coffee-bean text-xs p-0 h-auto hover:underline transition-all">
              See more suggestions
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Weekly Challenge */}
      <Card className="bg-gradient-to-br from-chai-orange to-espresso text-white border-0">
        <CardContent className="p-4">
          <h3 className="font-semibold mb-2 flex items-center">
            <Trophy className="w-4 h-4 mr-2" />
            Weekly Challenge
          </h3>
          <p className="text-sm opacity-90 mb-3">
            Try 3 new cafes this week and share your experiences!
          </p>
          <div className="flex items-center justify-between mb-2">
            <div className="text-xs">
              <span className="font-medium">Progress: 1/3</span>
            </div>
            <Button 
              size="sm" 
              variant="secondary"
              className="text-xs bg-white bg-opacity-20 hover:bg-opacity-30 text-white border-0"
            >
              View Details
            </Button>
          </div>
          <Progress value={33} className="h-2 bg-white bg-opacity-20" />
        </CardContent>
      </Card>
    </aside>
  );
}
