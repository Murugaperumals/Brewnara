import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Camera, MapPin, Smile, User } from "lucide-react";

const moodOptions = [
  { value: "energized", label: "Energized", emoji: "⚡" },
  { value: "peaceful", label: "Peaceful", emoji: "🧘" },
  { value: "focused", label: "Focused", emoji: "🎯" },
  { value: "happy", label: "Happy", emoji: "😊" },
  { value: "relaxed", label: "Relaxed", emoji: "😌" },
  { value: "inspired", label: "Inspired", emoji: "✨" },
];

const beverageOptions = [
  { value: "coffee", label: "Coffee" },
  { value: "espresso", label: "Espresso" },
  { value: "cappuccino", label: "Cappuccino" },
  { value: "latte", label: "Latte" },
  { value: "americano", label: "Americano" },
  { value: "cold-brew", label: "Cold Brew" },
  { value: "green-tea", label: "Green Tea" },
  { value: "black-tea", label: "Black Tea" },
  { value: "chai", label: "Chai" },
  { value: "matcha", label: "Matcha" },
  { value: "oolong", label: "Oolong" },
  { value: "herbal-tea", label: "Herbal Tea" },
];

const experienceOptions = [
  { value: "first-visit", label: "First Visit" },
  { value: "regular-spot", label: "Regular Spot" },
  { value: "work-session", label: "Work Session" },
  { value: "date", label: "Date" },
  { value: "meeting", label: "Meeting" },
  { value: "solo-time", label: "Solo Time" },
  { value: "afternoon-ritual", label: "Afternoon Ritual" },
  { value: "morning-routine", label: "Morning Routine" },
];

export default function CreatePostCard() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [content, setContent] = useState("");
  const [location, setLocation] = useState("");
  const [mood, setMood] = useState("");
  const [beverage, setBeverage] = useState("");
  const [experience, setExperience] = useState("");
  const [imageUrl, setImageUrl] = useState("");

  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createPostMutation = useMutation({
    mutationFn: async (postData: any) => {
      await apiRequest("/api/posts", "POST", postData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      toast({
        title: "Success",
        description: "Your post has been shared!",
      });
      // Reset form
      setContent("");
      setLocation("");
      setMood("");
      setBeverage("");
      setExperience("");
      setImageUrl("");
      setIsExpanded(false);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create post. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    if (!content.trim()) {
      toast({
        title: "Error",
        description: "Please enter some content for your post.",
        variant: "destructive",
      });
      return;
    }

    createPostMutation.mutate({
      content,
      location: location || null,
      mood: mood || null,
      beverage: beverage || null,
      experience: experience || null,
      imageUrl: imageUrl || null,
    });
  };

  return (
    <Card className="m-4 border-latte-foam">
      <CardContent className="p-4">
        <div className="flex items-center space-x-3 mb-4">
          {user?.profileImageUrl ? (
            <img
              src={user.profileImageUrl}
              alt="Your profile"
              className="w-10 h-10 rounded-full object-cover"
            />
          ) : (
            <div className="w-10 h-10 bg-espresso rounded-full flex items-center justify-center">
              <User className="w-5 h-5 text-white" />
            </div>
          )}
          <Dialog open={isExpanded} onOpenChange={setIsExpanded}>
            <DialogTrigger asChild>
              <Input
                placeholder="Share your coffee or tea moment..."
                className="flex-1 p-3 bg-warm-cream rounded-full border-latte-foam focus:ring-2 focus:ring-espresso cursor-pointer"
                readOnly
              />
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Share Your Experience</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="content">What's on your mind?</Label>
                  <Textarea
                    id="content"
                    placeholder="Share your coffee or tea experience..."
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    className="min-h-[100px]"
                  />
                </div>

                <div>
                  <Label htmlFor="location">Location (optional)</Label>
                  <Input
                    id="location"
                    placeholder="e.g., Blue Bottle Coffee, Mission"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                  />
                </div>

                <div>
                  <Label htmlFor="imageUrl">Image URL (optional)</Label>
                  <Input
                    id="imageUrl"
                    placeholder="https://example.com/image.jpg"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="mood">Mood</Label>
                    <Select value={mood} onValueChange={setMood}>
                      <SelectTrigger>
                        <SelectValue placeholder="How do you feel?" />
                      </SelectTrigger>
                      <SelectContent>
                        {moodOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.emoji} {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="beverage">Beverage</Label>
                    <Select value={beverage} onValueChange={setBeverage}>
                      <SelectTrigger>
                        <SelectValue placeholder="What are you drinking?" />
                      </SelectTrigger>
                      <SelectContent>
                        {beverageOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="experience">Experience</Label>
                    <Select value={experience} onValueChange={setExperience}>
                      <SelectTrigger>
                        <SelectValue placeholder="What's the occasion?" />
                      </SelectTrigger>
                      <SelectContent>
                        {experienceOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex justify-end space-x-2">
                  <Button
                    variant="outline"
                    onClick={() => setIsExpanded(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleSubmit}
                    disabled={createPostMutation.isPending}
                    className="bg-espresso hover:bg-coffee-bean text-white"
                  >
                    {createPostMutation.isPending ? "Sharing..." : "Share"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-latte-foam">
          <div className="flex space-x-4">
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-2 px-3 py-2 text-gray-600 hover:bg-warm-cream rounded-lg transition-colors"
            >
              <Camera className="w-4 h-4 text-tea-green" />
              <span className="text-sm">Photo</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-2 px-3 py-2 text-gray-600 hover:bg-warm-cream rounded-lg transition-colors"
            >
              <MapPin className="w-4 h-4 text-chai-orange" />
              <span className="text-sm">Location</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-2 px-3 py-2 text-gray-600 hover:bg-warm-cream rounded-lg transition-colors"
            >
              <Smile className="w-4 h-4 text-yellow-500" />
              <span className="text-sm">Mood</span>
            </Button>
          </div>
          <Button
            onClick={() => setIsExpanded(true)}
            className="px-6 py-2 bg-espresso text-white rounded-full hover:bg-coffee-bean transition-colors font-medium"
          >
            Share
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
