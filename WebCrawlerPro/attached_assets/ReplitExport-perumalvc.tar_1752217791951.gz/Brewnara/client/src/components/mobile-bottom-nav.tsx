import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { 
  Home, 
  Compass, 
  MapPin, 
  User,
  Plus
} from "lucide-react";

const navItems = [
  { name: "Home", href: "/home", icon: Home, current: true },
  { name: "Discover", href: "/discover", icon: Compass, current: false },
  { name: "Nearby", href: "/nearby", icon: MapPin, current: false },
  { name: "Profile", href: "/profile", icon: User, current: false },
];

export default function MobileBottomNav() {
  return (
    <>
      {/* Floating Action Button */}
      <Button className="lg:hidden fixed bottom-20 right-6 w-14 h-14 bg-espresso text-white rounded-full shadow-lg hover:bg-coffee-bean transition-colors flex items-center justify-center z-50">
        <Plus className="w-6 h-6" />
      </Button>

      {/* Bottom Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-latte-foam z-40">
        <div className="flex items-center justify-around h-16 px-4">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <a
                key={item.name}
                href={item.href}
                className={cn(
                  "flex flex-col items-center space-y-1 h-auto py-2 px-3 rounded-lg transition-colors",
                  item.current ? "text-espresso" : "text-gray-400 hover:text-espresso"
                )}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs">{item.name}</span>
              </a>
            );
          })}
        </div>
      </nav>
    </>
  );
}
