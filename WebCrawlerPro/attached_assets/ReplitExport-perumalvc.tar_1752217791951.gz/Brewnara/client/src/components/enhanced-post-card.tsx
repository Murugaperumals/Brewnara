import { useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import type { PostWithUser, CommentWithUser } from "@shared/schema";
import { 
  Heart, 
  MessageCircle, 
  Share, 
  Send,
  MoreHorizontal,
  User,
  Coffee,
  Smile,
  Star,
  Leaf,
  MapPin,
  Camera,
  Image as ImageIcon
} from "lucide-react";

interface PostCardProps {
  post: PostWithUser;
}

const getMoodEmoji = (mood: string | null) => {
  const moodMap: Record<string, string> = {
    energized: "⚡",
    peaceful: "🧘",
    focused: "🎯",
    happy: "😊",
    relaxed: "😌",
    inspired: "✨",
  };
  return mood ? moodMap[mood] || "😊" : "";
};

const getBeverageIcon = (beverage: string | null) => {
  if (!beverage) return null;
  return beverage.includes("tea") ? "🍃" : "☕";
};

const getExperienceIcon = (experience: string | null) => {
  const experienceMap: Record<string, string> = {
    "first-visit": "⭐",
    "regular-spot": "🏠",
    "work-session": "💻",
    "date": "💕",
    "meeting": "🤝",
    "solo-time": "🧘",
    "afternoon-ritual": "🕐",
    "morning-routine": "🌅",
  };
  return experience ? experienceMap[experience] || "✨" : "";
};

// Reaction emojis matching the uploaded sample
const reactionEmojis = {
  like: "👍",
  love: "❤️",
  laugh: "😂",
  wow: "😮",
  sad: "😢",
  angry: "😡"
};

export default function EnhancedPostCard({ post }: PostCardProps) {
  const [isLiked, setIsLiked] = useState(post.isLiked);
  const [likesCount, setLikesCount] = useState(post.likesCount);
  const [showComments, setShowComments] = useState(false);
  const [showReactions, setShowReactions] = useState(false);
  const [newComment, setNewComment] = useState("");

  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: comments = [] } = useQuery<CommentWithUser[]>({
    queryKey: ["/api/posts", post.id, "comments"],
    enabled: showComments,
  });

  const likeMutation = useMutation({
    mutationFn: async () => {
      await apiRequest(`/api/posts/${post.id}/like`, "POST");
    },
    onSuccess: () => {
      setIsLiked(!isLiked);
      setLikesCount(isLiked ? likesCount - 1 : likesCount + 1);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Please log in",
          description: "You need to be logged in to like posts",
          variant: "destructive",
        });
        return;
      }
      toast({
        title: "Error",
        description: "Failed to like post. Please try again.",
        variant: "destructive",
      });
    },
  });

  const commentMutation = useMutation({
    mutationFn: async (content: string) => {
      await apiRequest(`/api/posts/${post.id}/comments`, "POST", { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts", post.id, "comments"] });
      setNewComment("");
      toast({
        title: "Comment added!",
        description: "Your comment has been posted",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Please log in",
          description: "You need to be logged in to comment",
          variant: "destructive",
        });
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add comment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleLike = () => {
    likeMutation.mutate();
  };

  const handleComment = () => {
    if (!newComment.trim()) return;
    commentMutation.mutate(newComment);
  };

  const formatLabel = (value: string) => {
    return value.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  return (
    <Card className="border-gray-200 overflow-hidden bg-white shadow-sm hover:shadow-md transition-all duration-200">
      {/* Post Header */}
      <CardContent className="p-0">
        <div className="p-4 pb-3">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-3">
              {post.user.profileImageUrl ? (
                <img
                  src={post.user.profileImageUrl}
                  alt={`${post.user.firstName || post.user.email} profile`}
                  className="w-10 h-10 rounded-full object-cover border border-gray-200"
                />
              ) : (
                <div className="w-10 h-10 bg-gray-500 rounded-full flex items-center justify-center">
                  <User className="w-5 h-5 text-white" />
                </div>
              )}
              <div>
                <h3 className="font-semibold text-gray-900 hover:underline cursor-pointer">
                  {post.user.firstName ? `${post.user.firstName} ${post.user.lastName || ''}` : post.user.email}
                </h3>
                <div className="flex items-center space-x-1 text-sm text-gray-500">
                  <span>{formatDistanceToNow(new Date(post.createdAt))} ago</span>
                  {post.location && (
                    <>
                      <span>•</span>
                      <MapPin className="w-3 h-3" />
                      <span className="hover:underline cursor-pointer">{post.location}</span>
                    </>
                  )}
                </div>
              </div>
            </div>
            <Button variant="ghost" size="sm" className="text-gray-400 hover:bg-gray-100">
              <MoreHorizontal className="w-5 h-5" />
            </Button>
          </div>

          {/* Post Content */}
          <div className="mb-3">
            <p className="text-gray-900 leading-relaxed">{post.content}</p>
          </div>

          {/* Tags */}
          {(post.mood || post.beverage || post.experience) && (
            <div className="flex flex-wrap gap-2 mb-3">
              {post.mood && (
                <Badge variant="secondary" className="bg-yellow-50 text-yellow-700 border-yellow-200 hover:bg-yellow-100">
                  <Smile className="w-3 h-3 mr-1" />
                  {getMoodEmoji(post.mood)} {formatLabel(post.mood)}
                </Badge>
              )}
              {post.beverage && (
                <Badge variant="secondary" className="bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100">
                  <Coffee className="w-3 h-3 mr-1" />
                  {getBeverageIcon(post.beverage)} {formatLabel(post.beverage)}
                </Badge>
              )}
              {post.experience && (
                <Badge variant="secondary" className="bg-green-50 text-green-700 border-green-200 hover:bg-green-100">
                  <Star className="w-3 h-3 mr-1" />
                  {getExperienceIcon(post.experience)} {formatLabel(post.experience)}
                </Badge>
              )}
            </div>
          )}
        </div>

        {/* Post Image */}
        {post.imageUrl && (
          <div className="relative">
            <img
              src={post.imageUrl}
              alt="Post content"
              className="w-full h-auto object-cover"
            />
          </div>
        )}

        {/* Reactions and Stats */}
        <div className="px-4 py-2">
          <div className="flex items-center justify-between text-sm text-gray-500">
            <div className="flex items-center space-x-1">
              {likesCount > 0 && (
                <>
                  <div className="flex -space-x-1">
                    <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center text-xs">
                      👍
                    </div>
                    <div className="w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-xs">
                      ❤️
                    </div>
                  </div>
                  <span className="hover:underline cursor-pointer">{likesCount}</span>
                </>
              )}
            </div>
            <div className="flex items-center space-x-4">
              {post.commentsCount > 0 && (
                <span className="hover:underline cursor-pointer">
                  {post.commentsCount} comment{post.commentsCount !== 1 ? 's' : ''}
                </span>
              )}
              <span className="hover:underline cursor-pointer">Share</span>
            </div>
          </div>
        </div>

        <Separator className="my-0" />

        {/* Action Buttons */}
        <div className="px-4 py-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1">
              <div className="relative">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleLike}
                  disabled={likeMutation.isPending}
                  onMouseEnter={() => setShowReactions(true)}
                  onMouseLeave={() => setShowReactions(false)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 hover:bg-gray-100 ${
                    isLiked ? "text-blue-600" : "text-gray-600"
                  }`}
                >
                  <Heart className={`w-5 h-5 ${isLiked ? "fill-current" : ""}`} />
                  <span className="font-medium">Like</span>
                </Button>
                
                {/* Reaction Picker */}
                {showReactions && (
                  <div 
                    className="absolute bottom-full left-0 mb-2 bg-white border border-gray-200 rounded-full shadow-lg p-2 flex space-x-1 z-50"
                    onMouseEnter={() => setShowReactions(true)}
                    onMouseLeave={() => setShowReactions(false)}
                  >
                    {Object.entries(reactionEmojis).map(([type, emoji]) => (
                      <button
                        key={type}
                        className="w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center text-lg hover:scale-110 transition-transform"
                        onClick={() => {
                          handleLike();
                          setShowReactions(false);
                        }}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowComments(!showComments)}
              className="flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 hover:bg-gray-100 text-gray-600"
            >
              <MessageCircle className="w-5 h-5" />
              <span className="font-medium">Comment</span>
            </Button>

            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 hover:bg-gray-100 text-gray-600"
            >
              <Send className="w-5 h-5" />
              <span className="font-medium">Send</span>
            </Button>

            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 hover:bg-gray-100 text-gray-600"
            >
              <Share className="w-5 h-5" />
              <span className="font-medium">Share</span>
            </Button>
          </div>
        </div>

        {/* Comments Section */}
        {showComments && (
          <>
            <Separator className="my-0" />
            <div className="px-4 py-3 bg-gray-50">
              {/* Add Comment */}
              <div className="flex items-start space-x-3 mb-3">
                {user?.profileImageUrl ? (
                  <img
                    src={user.profileImageUrl}
                    alt="Your profile"
                    className="w-8 h-8 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-8 h-8 bg-gray-500 rounded-full flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>
                )}
                <div className="flex-1 relative">
                  <Textarea
                    placeholder="Write a comment..."
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    className="min-h-[36px] max-h-24 rounded-full border-gray-300 bg-white px-4 py-2 pr-20 resize-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        if (newComment.trim()) {
                          handleComment();
                        }
                      }
                    }}
                  />
                  <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-7 h-7 p-0 text-gray-400 hover:text-gray-600"
                    >
                      <Smile className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-7 h-7 p-0 text-gray-400 hover:text-gray-600"
                    >
                      <Camera className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-7 h-7 p-0 text-gray-400 hover:text-gray-600"
                    >
                      <ImageIcon className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Comments List */}
              <div className="space-y-3">
                {comments.length === 0 ? (
                  <div className="text-center py-4 text-gray-500">
                    <MessageCircle className="w-8 h-8 mx-auto text-gray-300 mb-2" />
                    <p className="text-sm">No comments yet</p>
                    <p className="text-xs">Be the first to comment!</p>
                  </div>
                ) : (
                  comments
                    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
                    .map((comment) => (
                      <div key={comment.id} className="flex items-start space-x-2">
                        {comment.user.profileImageUrl ? (
                          <img
                            src={comment.user.profileImageUrl}
                            alt={`${comment.user.firstName || comment.user.email} profile`}
                            className="w-8 h-8 rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-8 h-8 bg-gray-500 rounded-full flex items-center justify-center">
                            <User className="w-4 h-4 text-white" />
                          </div>
                        )}
                        <div className="flex-1">
                          <div className="bg-white rounded-2xl px-3 py-2 border border-gray-200">
                            <div className="font-semibold text-sm text-gray-900 mb-1">
                              {comment.user.firstName ? `${comment.user.firstName} ${comment.user.lastName || ''}` : comment.user.email}
                            </div>
                            <p className="text-sm text-gray-800">{comment.content}</p>
                          </div>
                          <div className="flex items-center space-x-4 mt-1 ml-3">
                            <button className="text-xs text-gray-500 hover:text-gray-700 font-semibold">
                              Like
                            </button>
                            <button className="text-xs text-gray-500 hover:text-gray-700 font-semibold">
                              Reply
                            </button>
                            <span className="text-xs text-gray-400">
                              {formatDistanceToNow(new Date(comment.createdAt))} ago
                            </span>
                          </div>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}