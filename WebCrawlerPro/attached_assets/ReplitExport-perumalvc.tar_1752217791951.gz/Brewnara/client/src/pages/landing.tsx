import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Coffee, Heart, MapPin, Users } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-warm-cream">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="flex justify-center items-center space-x-3 mb-8">
              <div className="w-16 h-16 from-espresso to-coffee-bean rounded-lg flex items-center justify-center bg-[#542a00]">
                <Coffee className="text-white text-2xl" />
              </div>
              <h1 className="text-5xl font-bold text-coffee-bean font-serif">Brewnara</h1>
            </div>
            
            <h2 className="text-3xl sm:text-4xl font-bold text-coffee-bean mb-6">
              Share Your Coffee & Tea Moments
            </h2>
            
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Connect with fellow coffee and tea enthusiasts. Share your experiences, discover new cafes, 
              and build a community around the beverages we love.
            </p>
            
            <Button 
              size="lg" 
              className="bg-espresso hover:bg-coffee-bean text-white px-8 py-3 text-lg"
              onClick={() => window.location.href = '/auth'}
            >
              Get Started
            </Button>
          </div>
        </div>
      </div>
      {/* Features Section */}
      <div className="py-24 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-coffee-bean mb-4">
              Why Coffee & Tea Lovers Choose Brewnara
            </h3>
            <p className="text-gray-600 text-lg">
              Everything you need to share and discover amazing coffee and tea experiences
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center border-latte-foam">
              <CardHeader>
                <div className="w-12 h-12 bg-chai-orange rounded-lg flex items-center justify-center mx-auto mb-4">
                  <MapPin className="text-white" />
                </div>
                <CardTitle className="text-coffee-bean">Location-Based</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Tag your posts with cafe locations and discover new spots near you
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center border-latte-foam">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4 bg-[#6b3719]">
                  <Heart className="text-white" />
                </div>
                <CardTitle className="text-coffee-bean">Share Emotions</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Express how your coffee or tea made you feel with mood indicators
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center border-latte-foam">
              <CardHeader>
                <div className="w-12 h-12 bg-espresso rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Users className="text-white" />
                </div>
                <CardTitle className="text-coffee-bean">Community</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Connect with other enthusiasts, comment, like, and share experiences
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center border-latte-foam">
              <CardHeader>
                <div className="w-12 h-12 bg-chai-orange rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Coffee className="text-white" />
                </div>
                <CardTitle className="text-coffee-bean">Discover</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Find trending cafes and get recommendations from the community
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      {/* CTA Section */}
      <div className="py-24 bg-gradient-to-r from-espresso to-coffee-bean">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold mb-6 text-[#542a00]">
            Ready to Share Your Next Coffee Moment?
          </h3>
          <p className="text-xl mb-8 text-[#e47000]">
            Join thousands of coffee and tea lovers already sharing their experiences
          </p>
          <Button 
            size="lg" 
            variant="secondary" 
            className="text-coffee-bean hover:bg-gray-100 px-8 py-3 text-lg bg-[#d26c1e]"
            onClick={() => window.location.href = '/auth'}
          >
            Join Brewnara Today
          </Button>
        </div>
      </div>
    </div>
  );
}
