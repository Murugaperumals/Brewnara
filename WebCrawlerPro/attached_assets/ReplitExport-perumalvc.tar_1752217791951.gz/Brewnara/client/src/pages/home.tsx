import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import NavigationHeader from "@/components/navigation-header";
import Sidebar from "@/components/sidebar";
import CreatePostCard from "@/components/create-post-card";
import FacebookStylePostCard from "@/components/facebook-style-post-card";
import RightSidebar from "@/components/right-sidebar";
import MobileBottomNav from "@/components/mobile-bottom-nav";
import { useQuery } from "@tanstack/react-query";
import type { PostWithUser } from "@shared/schema";

export default function Home() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to auth if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      window.location.href = "/auth";
      return;
    }
  }, [isAuthenticated, isLoading]);

  const { data: posts = [], isLoading: postsLoading } = useQuery<PostWithUser[]>({
    queryKey: ["/api/posts"],
    enabled: isAuthenticated,
  });

  if (isLoading || !isAuthenticated) {
    return null; // Loading or redirecting
  }

  return (
    <div className="min-h-screen bg-warm-cream">
      <NavigationHeader />
      
      <div className="flex max-w-6xl mx-auto">
        <Sidebar />
        
        <main className="flex-1 min-h-screen">
          <CreatePostCard />
          
          <div className="space-y-4 px-4 pb-20 lg:pb-8">
            {postsLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="bg-white rounded-lg shadow-sm border border-latte-foam p-4">
                    <div className="animate-pulse">
                      <div className="flex items-center space-x-3 mb-4">
                        <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                        <div className="space-y-2">
                          <div className="h-4 bg-gray-200 rounded w-32"></div>
                          <div className="h-3 bg-gray-200 rounded w-24"></div>
                        </div>
                      </div>
                      <div className="h-80 bg-gray-200 rounded mb-4"></div>
                      <div className="space-y-2">
                        <div className="h-4 bg-gray-200 rounded w-full"></div>
                        <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : posts.length === 0 ? (
              <div className="bg-white rounded-lg shadow-sm border border-latte-foam p-8 text-center">
                <h3 className="text-lg font-semibold text-coffee-bean mb-2">No posts yet</h3>
                <p className="text-gray-600">Be the first to share your coffee or tea experience!</p>
              </div>
            ) : (
              posts.map((post) => (
                <FacebookStylePostCard key={post.id} post={post} />
              ))
            )}
          </div>
        </main>
        
        <RightSidebar />
      </div>
      
      <MobileBottomNav />
    </div>
  );
}
