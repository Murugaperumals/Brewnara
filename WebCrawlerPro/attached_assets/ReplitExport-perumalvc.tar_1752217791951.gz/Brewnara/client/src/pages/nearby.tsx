import { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import { Icon, LatLng, DivIcon } from "leaflet";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Coffee, MapPin, Navigation, Star, Users, Clock } from "lucide-react";
import "leaflet/dist/leaflet.css";

// Animated marker component
function AnimatedMarker({ position, data, isSelected, onClick }: any) {
  const map = useMap();
  
  const customIcon = new DivIcon({
    html: `
      <div class="animate-bounce cursor-pointer transform transition-all duration-300 ${
        isSelected ? 'scale-125' : 'hover:scale-110'
      }">
        <div class="relative">
          <div class="w-8 h-8 bg-espresso rounded-full shadow-lg border-2 border-white flex items-center justify-center">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
              <path d="M2 21h19l-8-8V8l5-5V1H6v2l5 5v5l-8 8h-1z"/>
            </svg>
          </div>
          <div class="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-espresso"></div>
          ${data.isNew ? '<div class="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>' : ''}
        </div>
      </div>
    `,
    className: 'custom-marker',
    iconSize: [32, 40],
    iconAnchor: [16, 40],
  });

  return (
    <Marker
      position={position}
      icon={customIcon}
      eventHandlers={{
        click: () => onClick(data),
      }}
    >
      <Popup>
        <div className="text-center p-2">
          <h3 className="font-bold text-coffee-bean">{data.name}</h3>
          <p className="text-sm text-gray-600">{data.type}</p>
          <div className="flex items-center justify-center mt-1">
            <Star className="w-4 h-4 text-yellow-500 mr-1" />
            <span className="text-sm">{data.rating}</span>
          </div>
        </div>
      </Popup>
    </Marker>
  );
}

// Sample coffee shop data
const coffeeShops = [
  {
    id: 1,
    name: "Blue Bottle Coffee",
    type: "Specialty Coffee",
    position: [37.7749, -122.4194] as [number, number],
    rating: 4.8,
    distance: "0.2 miles",
    openUntil: "8:00 PM",
    crowdLevel: "busy",
    specialties: ["Single Origin", "Pour Over"],
    isNew: true,
    posts: 142,
  },
  {
    id: 2,
    name: "Ritual Coffee Roasters",
    type: "Coffee Roastery",
    position: [37.7849, -122.4094] as [number, number],
    rating: 4.6,
    distance: "0.5 miles",
    openUntil: "7:00 PM",
    crowdLevel: "moderate",
    specialties: ["Espresso", "Cold Brew"],
    isNew: false,
    posts: 89,
  },
  {
    id: 3,
    name: "Philz Coffee",
    type: "Custom Blends",
    position: [37.7649, -122.4294] as [number, number],
    rating: 4.5,
    distance: "0.8 miles",
    openUntil: "9:00 PM",
    crowdLevel: "quiet",
    specialties: ["Custom Blends", "Iced Coffee"],
    isNew: false,
    posts: 67,
  },
  {
    id: 4,
    name: "Sightglass Coffee",
    type: "Artisan Coffee",
    position: [37.7549, -122.4394] as [number, number],
    rating: 4.7,
    distance: "1.1 miles",
    openUntil: "6:00 PM",
    crowdLevel: "busy",
    specialties: ["Light Roast", "Pastries"],
    isNew: false,
    posts: 95,
  },
  {
    id: 5,
    name: "Tea Garden House",
    type: "Tea House",
    position: [37.7449, -122.4194] as [number, number],
    rating: 4.4,
    distance: "1.3 miles",
    openUntil: "7:30 PM",
    crowdLevel: "quiet",
    specialties: ["Green Tea", "Bubble Tea"],
    isNew: true,
    posts: 34,
  }
];

export default function NearbyPage() {
  const [selectedShop, setSelectedShop] = useState<any>(null);
  const [userLocation, setUserLocation] = useState<[number, number]>([37.7749, -122.4194]);
  const [filter, setFilter] = useState<string>("all");

  // Get user's location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation([position.coords.latitude, position.coords.longitude]);
        },
        (error) => {
          console.log("Location access denied, using default location");
        }
      );
    }
  }, []);

  const filteredShops = coffeeShops.filter(shop => {
    if (filter === "all") return true;
    if (filter === "coffee") return shop.type.toLowerCase().includes("coffee");
    if (filter === "tea") return shop.type.toLowerCase().includes("tea");
    if (filter === "new") return shop.isNew;
    return true;
  });

  const getCrowdColor = (level: string) => {
    switch (level) {
      case "quiet": return "text-green-600 bg-green-100";
      case "moderate": return "text-yellow-600 bg-yellow-100";
      case "busy": return "text-red-600 bg-red-100";
      default: return "text-gray-600 bg-gray-100";
    }
  };

  return (
    <div className="min-h-screen bg-warm-cream">
      {/* Header */}
      <div className="bg-white border-b border-latte-foam p-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-coffee-bean flex items-center">
                <MapPin className="w-6 h-6 text-chai-orange mr-2" />
                Nearby Brews
              </h1>
              <p className="text-gray-600 text-sm">Discover coffee and tea spots around you</p>
            </div>
            <div className="flex space-x-2">
              <Button
                variant={filter === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter("all")}
                className={filter === "all" ? "bg-espresso text-white" : ""}
              >
                All
              </Button>
              <Button
                variant={filter === "coffee" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter("coffee")}
                className={filter === "coffee" ? "bg-espresso text-white" : ""}
              >
                <Coffee className="w-4 h-4 mr-1" />
                Coffee
              </Button>
              <Button
                variant={filter === "tea" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter("tea")}
                className={filter === "tea" ? "bg-espresso text-white" : ""}
              >
                🍃 Tea
              </Button>
              <Button
                variant={filter === "new" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter("new")}
                className={filter === "new" ? "bg-espresso text-white" : ""}
              >
                ✨ New
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Map */}
          <div className="lg:col-span-2">
            <Card className="h-[70vh] overflow-hidden">
              <CardContent className="p-0 h-full">
                <MapContainer
                  center={userLocation}
                  zoom={14}
                  className="h-full w-full"
                  zoomControl={true}
                >
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                  />
                  
                  {/* User location marker */}
                  <Marker
                    position={userLocation}
                    icon={new DivIcon({
                      html: `
                        <div class="relative">
                          <div class="w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-lg animate-pulse"></div>
                          <div class="absolute inset-0 w-4 h-4 bg-blue-500 rounded-full opacity-30 animate-ping"></div>
                        </div>
                      `,
                      className: 'user-location-marker',
                      iconSize: [16, 16],
                      iconAnchor: [8, 8],
                    })}
                  >
                    <Popup>
                      <div className="text-center">
                        <Navigation className="w-4 h-4 mx-auto text-blue-500" />
                        <p className="text-sm font-medium">You are here</p>
                      </div>
                    </Popup>
                  </Marker>

                  {/* Coffee shop markers */}
                  {filteredShops.map((shop) => (
                    <AnimatedMarker
                      key={shop.id}
                      position={shop.position}
                      data={shop}
                      isSelected={selectedShop?.id === shop.id}
                      onClick={setSelectedShop}
                    />
                  ))}
                </MapContainer>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Selected shop details */}
            {selectedShop ? (
              <Card className="border-espresso">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center justify-between">
                    <span className="text-coffee-bean">{selectedShop.name}</span>
                    {selectedShop.isNew && (
                      <Badge className="bg-red-500 text-white">New!</Badge>
                    )}
                  </CardTitle>
                  <p className="text-sm text-gray-600">{selectedShop.type}</p>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-yellow-500 mr-1" />
                      <span className="font-medium">{selectedShop.rating}</span>
                    </div>
                    <span className="text-sm text-gray-600">{selectedShop.distance}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 text-gray-500 mr-1" />
                      <span className="text-sm">Open until {selectedShop.openUntil}</span>
                    </div>
                    <Badge className={getCrowdColor(selectedShop.crowdLevel)}>
                      {selectedShop.crowdLevel}
                    </Badge>
                  </div>

                  <div className="flex items-center">
                    <Users className="w-4 h-4 text-gray-500 mr-1" />
                    <span className="text-sm">{selectedShop.posts} posts</span>
                  </div>

                  <div>
                    <p className="text-sm font-medium text-coffee-bean mb-1">Specialties:</p>
                    <div className="flex flex-wrap gap-1">
                      {selectedShop.specialties.map((specialty: string, index: number) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex space-x-2 pt-2">
                    <Button size="sm" className="flex-1 bg-espresso text-white hover:bg-coffee-bean">
                      Get Directions
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1">
                      View Posts
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="p-6 text-center">
                  <MapPin className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-600">Click on a marker to see details</p>
                </CardContent>
              </Card>
            )}

            {/* Quick stats */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-coffee-bean">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Total spots:</span>
                  <span className="font-medium">{filteredShops.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">New this week:</span>
                  <span className="font-medium">{filteredShops.filter(s => s.isNew).length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Avg rating:</span>
                  <span className="font-medium">
                    {(filteredShops.reduce((acc, shop) => acc + shop.rating, 0) / filteredShops.length).toFixed(1)}
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Trending locations */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-coffee-bean">Trending Now</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {filteredShops
                  .sort((a, b) => b.posts - a.posts)
                  .slice(0, 3)
                  .map((shop, index) => (
                    <div
                      key={shop.id}
                      className="flex items-center justify-between p-2 rounded-lg hover:bg-warm-cream cursor-pointer transition-colors"
                      onClick={() => setSelectedShop(shop)}
                    >
                      <div>
                        <p className="text-sm font-medium text-coffee-bean">{shop.name}</p>
                        <p className="text-xs text-gray-600">{shop.posts} posts</p>
                      </div>
                      <Badge className={`text-xs ${
                        index === 0 ? 'bg-yellow-100 text-yellow-700' :
                        index === 1 ? 'bg-orange-100 text-orange-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        #{index + 1}
                      </Badge>
                    </div>
                  ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}