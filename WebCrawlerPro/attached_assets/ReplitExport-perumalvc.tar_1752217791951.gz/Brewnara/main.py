from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from sqlalchemy import func, exists
from typing import List, Optional
from datetime import timedelta
import os

from database import get_db, create_tables
from models import User, Post, Comment, Like
from schemas import (
    UserCreate, UserLogin, User as UserSchema,
    PostCreate, Post as PostSchema,
    CommentCreate, Comment as CommentSchema,
    Token, ForgotPassword, ResetPassword
)
from auth import (
    authenticate_user, create_user, get_current_user, create_access_token,
    get_user_by_email, create_password_reset_token, get_password_reset_token,
    use_password_reset_token, update_user_password,
    ACCESS_TOKEN_EXPIRE_MINUTES
)

# Create FastAPI app
app = FastAPI(title="Brewnara API", description="Coffee & Tea Social Platform API")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure this properly for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create database tables on startup
@app.on_event("startup")
def startup_event():
    create_tables()

# Serve static files (React build)
if os.path.exists("dist"):
    app.mount("/static", StaticFiles(directory="dist/assets"), name="static")

# Authentication endpoints
@app.post("/api/register", response_model=UserSchema)
def register(user_data: UserCreate, db: Session = Depends(get_db)):
    """Register a new user."""
    # Check if user already exists
    existing_user = get_user_by_email(db, user_data.email)
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User already exists"
        )
    
    # Create user
    user = create_user(
        db, 
        email=user_data.email,
        password=user_data.password,
        first_name=user_data.first_name,
        last_name=user_data.last_name
    )
    return user

@app.post("/api/login", response_model=dict)
def login(user_credentials: UserLogin, db: Session = Depends(get_db)):
    """Login user and return access token."""
    user = authenticate_user(db, user_credentials.email, user_credentials.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid email or password"
        )
    
    # Create access token
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": str(user.id)}, expires_delta=access_token_expires
    )
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "email": user.email,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "profile_image_url": user.profile_image_url
        }
    }

@app.get("/api/user", response_model=UserSchema)
def get_current_user_info(current_user: User = Depends(get_current_user)):
    """Get current user information."""
    return current_user

@app.post("/api/forgot-password")
def forgot_password(data: ForgotPassword, db: Session = Depends(get_db)):
    """Send password reset token."""
    user = get_user_by_email(db, data.email)
    if user:
        token = create_password_reset_token(db, user.id)
        # In production, send email with token
        print(f"Password reset token for {data.email}: {token}")
    
    # Always return success for security
    return {"message": "If an account exists, a reset link has been sent"}

@app.post("/api/reset-password")
def reset_password(data: ResetPassword, db: Session = Depends(get_db)):
    """Reset password using token."""
    reset_token = get_password_reset_token(db, data.token)
    if not reset_token:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid or expired reset token"
        )
    
    # Update password
    update_user_password(db, reset_token.user_id, data.new_password)
    use_password_reset_token(db, reset_token.id)
    
    return {"message": "Password has been reset successfully"}

# Post endpoints
@app.get("/api/posts", response_model=List[PostSchema])
def get_posts(current_user: Optional[User] = None, db: Session = Depends(get_db)):
    """Get all posts with user information and like status."""
    try:
        # Get current user if authenticated (but don't require auth)
        from fastapi.security import HTTPBearer
        from fastapi import Request
        # This is a simplified approach - in production you'd handle this more elegantly
        pass
    except:
        current_user = None
    
    query = db.query(Post).join(User, Post.user_id == User.id)
    
    posts = []
    for post in query.order_by(Post.created_at.desc()).all():
        # Check if current user liked this post
        is_liked = False
        if current_user:
            is_liked = db.query(exists().where(
                Like.post_id == post.id,
                Like.user_id == current_user.id
            )).scalar()
        
        post_dict = {
            "id": post.id,
            "user_id": post.user_id,
            "content": post.content,
            "image_url": post.image_url,
            "location": post.location,
            "mood": post.mood,
            "beverage": post.beverage,
            "experience": post.experience,
            "likes_count": post.likes_count,
            "comments_count": post.comments_count,
            "created_at": post.created_at,
            "user": post.user,
            "is_liked": is_liked
        }
        posts.append(post_dict)
    
    return posts

@app.post("/api/posts", response_model=PostSchema)
def create_post(post_data: PostCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Create a new post."""
    db_post = Post(
        user_id=current_user.id,
        content=post_data.content,
        image_url=post_data.image_url,
        location=post_data.location,
        mood=post_data.mood,
        beverage=post_data.beverage,
        experience=post_data.experience
    )
    db.add(db_post)
    db.commit()
    db.refresh(db_post)
    
    # Return post with user info
    post_dict = {
        "id": db_post.id,
        "user_id": db_post.user_id,
        "content": db_post.content,
        "image_url": db_post.image_url,
        "location": db_post.location,
        "mood": db_post.mood,
        "beverage": db_post.beverage,
        "experience": db_post.experience,
        "likes_count": db_post.likes_count,
        "comments_count": db_post.comments_count,
        "created_at": db_post.created_at,
        "user": current_user,
        "is_liked": False
    }
    return post_dict

@app.post("/api/posts/{post_id}/like")
def toggle_like(post_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Toggle like on a post."""
    # Check if post exists
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    # Check if user already liked this post
    existing_like = db.query(Like).filter(
        Like.post_id == post_id,
        Like.user_id == current_user.id
    ).first()
    
    if existing_like:
        # Unlike
        db.delete(existing_like)
        post.likes_count = max(0, post.likes_count - 1)
        is_liked = False
    else:
        # Like
        new_like = Like(post_id=post_id, user_id=current_user.id)
        db.add(new_like)
        post.likes_count += 1
        is_liked = True
    
    db.commit()
    return {"is_liked": is_liked}

# Comment endpoints
@app.get("/api/posts/{post_id}/comments", response_model=List[CommentSchema])
def get_comments(post_id: int, db: Session = Depends(get_db)):
    """Get comments for a post."""
    comments = db.query(Comment).join(User, Comment.user_id == User.id).filter(
        Comment.post_id == post_id
    ).order_by(Comment.created_at.asc()).all()
    
    # Build nested comment tree
    comment_map = {}
    root_comments = []
    
    for comment in comments:
        comment_dict = {
            "id": comment.id,
            "post_id": comment.post_id,
            "user_id": comment.user_id,
            "parent_id": comment.parent_id,
            "content": comment.content,
            "created_at": comment.created_at,
            "user": comment.user,
            "replies": []
        }
        comment_map[comment.id] = comment_dict
        
        if comment.parent_id:
            if comment.parent_id in comment_map:
                comment_map[comment.parent_id]["replies"].append(comment_dict)
        else:
            root_comments.append(comment_dict)
    
    return root_comments

@app.post("/api/posts/{post_id}/comments", response_model=CommentSchema)
def create_comment(
    post_id: int, 
    comment_data: CommentCreate, 
    current_user: User = Depends(get_current_user), 
    db: Session = Depends(get_db)
):
    """Create a new comment on a post."""
    # Check if post exists
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    db_comment = Comment(
        post_id=post_id,
        user_id=current_user.id,
        parent_id=comment_data.parent_id,
        content=comment_data.content
    )
    db.add(db_comment)
    
    # Update comments count
    post.comments_count += 1
    
    db.commit()
    db.refresh(db_comment)
    
    return {
        "id": db_comment.id,
        "post_id": db_comment.post_id,
        "user_id": db_comment.user_id,
        "parent_id": db_comment.parent_id,
        "content": db_comment.content,
        "created_at": db_comment.created_at,
        "user": current_user,
        "replies": []
    }

# Serve React app
@app.get("/{path:path}")
def serve_react_app(path: str):
    """Serve React app for all non-API routes."""
    if path.startswith("api/"):
        raise HTTPException(status_code=404, detail="API endpoint not found")
    
    if os.path.exists("dist/index.html"):
        return FileResponse("dist/index.html")
    else:
        return {"message": "React app not built yet"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)