from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

# User schemas
class UserBase(BaseModel):
    email: EmailStr
    first_name: Optional[str] = None
    last_name: Optional[str] = None

class UserCreate(UserBase):
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class User(UserBase):
    id: int
    profile_image_url: Optional[str] = None
    provider: Optional[str] = None
    created_at: datetime
    
    class Config:
        from_attributes = True

# Post schemas
class PostBase(BaseModel):
    content: str
    image_url: Optional[str] = None
    location: Optional[str] = None
    mood: Optional[str] = None
    beverage: Optional[str] = None
    experience: Optional[str] = None

class PostCreate(PostBase):
    pass

class Post(PostBase):
    id: int
    user_id: int
    likes_count: int
    comments_count: int
    created_at: datetime
    user: User
    is_liked: bool = False
    
    class Config:
        from_attributes = True

# Comment schemas
class CommentBase(BaseModel):
    content: str
    parent_id: Optional[int] = None

class CommentCreate(CommentBase):
    pass

class Comment(CommentBase):
    id: int
    post_id: int
    user_id: int
    created_at: datetime
    user: User
    replies: Optional[List['Comment']] = []
    
    class Config:
        from_attributes = True

# Update forward reference
Comment.model_rebuild()

# Auth schemas
class Token(BaseModel):
    access_token: str
    token_type: str

class ForgotPassword(BaseModel):
    email: EmailStr

class ResetPassword(BaseModel):
    token: str
    new_password: str