from sqlalchemy import Column, Integer, String, DateTime, Text, Boolean, ForeignKey, func
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    password = Column(String, nullable=True)  # Nullable for OAuth users
    first_name = Column("firstName", String, nullable=True)
    last_name = Column("lastName", String, nullable=True)
    profile_image_url = Column("profileImageUrl", String, nullable=True)
    provider = Column(String, nullable=True)  # 'local', 'google', 'github'
    provider_id = Column("providerId", String, nullable=True)
    created_at = Column("createdAt", DateTime, default=func.now(), nullable=False)
    updated_at = Column("updatedAt", DateTime, default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    posts = relationship("Post", back_populates="user")
    comments = relationship("Comment", back_populates="user")
    likes = relationship("Like", back_populates="user")

class Post(Base):
    __tablename__ = "posts"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column("userId", Integer, ForeignKey("users.id"), nullable=False)
    content = Column(Text, nullable=False)
    image_url = Column("imageUrl", String, nullable=True)
    location = Column(String, nullable=True)
    mood = Column(String, nullable=True)
    beverage = Column(String, nullable=True)
    experience = Column(String, nullable=True)
    likes_count = Column("likesCount", Integer, default=0, nullable=False)
    comments_count = Column("commentsCount", Integer, default=0, nullable=False)
    created_at = Column("createdAt", DateTime, default=func.now(), nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="posts")
    comments = relationship("Comment", back_populates="post")
    likes = relationship("Like", back_populates="post")

class Comment(Base):
    __tablename__ = "comments"
    
    id = Column(Integer, primary_key=True, index=True)
    post_id = Column("postId", Integer, ForeignKey("posts.id"), nullable=False)
    user_id = Column("userId", Integer, ForeignKey("users.id"), nullable=False)
    parent_id = Column("parentId", Integer, ForeignKey("comments.id"), nullable=True)
    content = Column(Text, nullable=False)
    created_at = Column("createdAt", DateTime, default=func.now(), nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="comments")
    post = relationship("Post", back_populates="comments")
    parent = relationship("Comment", remote_side=[id])

class Like(Base):
    __tablename__ = "likes"
    
    id = Column(Integer, primary_key=True, index=True)
    post_id = Column("postId", Integer, ForeignKey("posts.id"), nullable=False)
    user_id = Column("userId", Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column("createdAt", DateTime, default=func.now(), nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="likes")
    post = relationship("Post", back_populates="likes")

class PasswordResetToken(Base):
    __tablename__ = "password_reset_tokens"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column("userId", Integer, ForeignKey("users.id"), nullable=False)
    token = Column(String, unique=True, nullable=False)
    expires_at = Column("expiresAt", DateTime, nullable=False)
    used = Column(Boolean, default=False, nullable=False)
    created_at = Column("createdAt", DateTime, default=func.now(), nullable=False)