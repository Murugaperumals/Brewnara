import { Pool, neonConfig } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-serverless";
import ws from "ws";

// ✅ Import your full schema
import * as schema from "@shared/schema";

// Neon config for WebSocket
neonConfig.webSocketConstructor = ws;

// Safety check for DATABASE_URL
if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Create the Neon connection pool
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Initialize Drizzle with Neon and your schema
export const db = drizzle(pool, { schema });
