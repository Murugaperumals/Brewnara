import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./auth-simple";
import { insertPostSchema, insertCommentSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // ✅ Auth
  setupAuth(app);

  // ✅ POSTS
  app.get("/api/posts", async (req: any, res) => {
    try {
      const userId = req.isAuthenticated() ? req.user?.id : undefined;
      const posts = await storage.getPosts(userId);
      res.json(posts);
    } catch (err) {
      console.error("Error fetching posts:", err);
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  app.post("/api/posts", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const validatedData = insertPostSchema.parse({
        ...req.body,
        userId,
      });
      const post = await storage.createPost(validatedData);
      res.status(201).json(post);
    } catch (err) {
      console.error("Error creating post:", err);
      res.status(500).json({ message: "Failed to create post" });
    }
  });

  app.get("/api/posts/:id", async (req: any, res) => {
    try {
      const postId = parseInt(req.params.id);
      const userId = req.isAuthenticated() ? req.user?.id : undefined;
      const post = await storage.getPost(postId, userId);
      if (!post) return res.status(404).json({ message: "Post not found" });
      res.json(post);
    } catch (err) {
      console.error("Error fetching post:", err);
      res.status(500).json({ message: "Failed to fetch post" });
    }
  });

  app.delete("/api/posts/:id", isAuthenticated, async (req: any, res) => {
    try {
      const postId = parseInt(req.params.id);
      const userId = req.user.id;
      const success = await storage.deletePost(postId, userId);
      if (!success)
        return res
          .status(404)
          .json({ message: "Post not found or unauthorized" });
      res.json({ message: "Post deleted successfully" });
    } catch (err) {
      console.error("Error deleting post:", err);
      res.status(500).json({ message: "Failed to delete post" });
    }
  });

  // ✅ LIKES
  app.post("/api/posts/:id/like", isAuthenticated, async (req: any, res) => {
    try {
      const postId = parseInt(req.params.id);
      const userId = req.user.id;
      const isLiked = await storage.toggleLike(postId, userId);
      res.json({ isLiked });
    } catch (err) {
      console.error("Error toggling like:", err);
      res.status(500).json({ message: "Failed to toggle like" });
    }
  });

  // ✅ COMMENTS: GET all comments (nested)
  app.get("/api/posts/:id/comments", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const comments = await storage.getComments(postId);

      // Optional: nest replies if storage returns flat list
      const buildTree = (flatComments) => {
        const map = new Map();
        const roots = [];

        flatComments.forEach((c) => map.set(c.id, { ...c, replies: [] }));

        flatComments.forEach((c) => {
          if (c.parentId) {
            const parent = map.get(c.parentId);
            if (parent) parent.replies.push(map.get(c.id));
          } else {
            roots.push(map.get(c.id));
          }
        });

        return roots;
      };

      const nested = buildTree(comments);
      res.json(nested);
    } catch (err) {
      console.error("Error fetching comments:", err);
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  // ✅ COMMENTS: POST create comment or reply
  app.post(
    "/api/posts/:id/comments",
    isAuthenticated,
    async (req: any, res) => {
      try {
        const postId = parseInt(req.params.id);
        const userId = req.user.id;

        const validatedData = insertCommentSchema.parse({
          ...req.body, // { content, optional parentId }
          postId,
          userId,
        });

        const comment = await storage.createComment(validatedData);
        res.status(201).json(comment);
      } catch (err) {
        console.error("Error creating comment:", err);
        res.status(500).json({ message: "Failed to create comment" });
      }
    },
  );

  // ✅ COMMENTS: DELETE comment
  app.delete("/api/comments/:id", isAuthenticated, async (req: any, res) => {
    try {
      const commentId = parseInt(req.params.id);
      const userId = req.user.id;
      const success = await storage.deleteComment(commentId, userId);
      if (!success)
        return res
          .status(404)
          .json({ message: "Comment not found or unauthorized" });
      res.json({ message: "Comment deleted successfully" });
    } catch (err) {
      console.error("Error deleting comment:", err);
      res.status(500).json({ message: "Failed to delete comment" });
    }
  });

  // ✅ USER PROFILE: fetch own posts
  app.get("/api/user/posts", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const posts = await storage.getPosts(userId);
      const userPosts = posts.filter((p) => p.userId === userId);
      res.json(userPosts);
    } catch (err) {
      console.error("Error fetching user posts:", err);
      res.status(500).json({ message: "Failed to fetch user posts" });
    }
  });

  // ✅ USER PROFILE: update (stub)
  app.patch("/api/user/profile", isAuthenticated, async (req: any, res) => {
    try {
      // Implement actual update logic in storage
      res.json({ message: "Profile updated successfully" });
    } catch (err) {
      console.error("Error updating profile:", err);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
