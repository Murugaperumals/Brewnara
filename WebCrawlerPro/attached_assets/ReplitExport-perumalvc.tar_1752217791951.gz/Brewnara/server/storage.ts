import {
  users,
  posts,
  comments,
  likes,
  passwordResetTokens,
  type User,
  type InsertUser,
  type Post,
  type InsertPost,
  type Comment,
  type InsertComment,
  type PostWithUser,
  type CommentWithUser,
  type PasswordResetToken,
  type InsertPasswordResetToken,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPassword(id: number, hashedPassword: string): Promise<void>;

  // Password reset operations
  createPasswordResetToken(token: InsertPasswordResetToken): Promise<PasswordResetToken>;
  getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined>;
  markTokenAsUsed(tokenId: number): Promise<void>;

  // Post operations
  createPost(post: InsertPost): Promise<Post>;
  getPosts(userId?: number): Promise<PostWithUser[]>;
  getPost(id: number, userId?: number): Promise<PostWithUser | undefined>;
  deletePost(id: number, userId: number): Promise<boolean>;

  // Like operations
  toggleLike(postId: number, userId: number): Promise<boolean>;

  // Comment operations
  createComment(comment: InsertComment): Promise<CommentWithUser>;
  getComments(postId: number): Promise<CommentWithUser[]>;
  deleteComment(id: number, userId: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
    return user;
  }

  async updateUserPassword(id: number, hashedPassword: string): Promise<void> {
    await db
      .update(users)
      .set({ password: hashedPassword, updatedAt: new Date() })
      .where(eq(users.id, id));
  }

  async createPasswordResetToken(tokenData: InsertPasswordResetToken): Promise<PasswordResetToken> {
    const [token] = await db
      .insert(passwordResetTokens)
      .values(tokenData)
      .returning();
    return token;
  }

  async getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined> {
    const [resetToken] = await db
      .select()
      .from(passwordResetTokens)
      .where(and(eq(passwordResetTokens.token, token), eq(passwordResetTokens.used, false)));
    return resetToken || undefined;
  }

  async markTokenAsUsed(tokenId: number): Promise<void> {
    await db
      .update(passwordResetTokens)
      .set({ used: true })
      .where(eq(passwordResetTokens.id, tokenId));
  }

  // Post operations
  async createPost(post: InsertPost): Promise<Post> {
    const [newPost] = await db.insert(posts).values(post).returning();
    return newPost;
  }

  async getPosts(userId?: number): Promise<PostWithUser[]> {
    const query = db
      .select({
        id: posts.id,
        userId: posts.userId,
        content: posts.content,
        imageUrl: posts.imageUrl,
        location: posts.location,
        mood: posts.mood,
        beverage: posts.beverage,
        experience: posts.experience,
        likesCount: posts.likesCount,
        commentsCount: posts.commentsCount,
        createdAt: posts.createdAt,
        user: {
          id: users.id,
          email: users.email,
          password: users.password,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          provider: users.provider,
          providerId: users.providerId,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
        isLiked: userId
          ? sql<boolean>`EXISTS(
              SELECT 1 FROM ${likes} 
              WHERE ${likes.postId} = ${posts.id} 
              AND ${likes.userId} = ${userId}
            )`
          : sql<boolean>`false`,
      })
      .from(posts)
      .innerJoin(users, eq(posts.userId, users.id))
      .orderBy(desc(posts.createdAt));

    return await query;
  }

  async getPost(id: number, userId?: number): Promise<PostWithUser | undefined> {
    const [post] = await db
      .select({
        id: posts.id,
        userId: posts.userId,
        content: posts.content,
        imageUrl: posts.imageUrl,
        location: posts.location,
        mood: posts.mood,
        beverage: posts.beverage,
        experience: posts.experience,
        likesCount: posts.likesCount,
        commentsCount: posts.commentsCount,
        createdAt: posts.createdAt,
        user: {
          id: users.id,
          email: users.email,
          password: users.password,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          provider: users.provider,
          providerId: users.providerId,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
        isLiked: userId
          ? sql<boolean>`EXISTS(
              SELECT 1 FROM ${likes} 
              WHERE ${likes.postId} = ${posts.id} 
              AND ${likes.userId} = ${userId}
            )`
          : sql<boolean>`false`,
      })
      .from(posts)
      .innerJoin(users, eq(posts.userId, users.id))
      .where(eq(posts.id, id));

    return post;
  }

  async deletePost(id: number, userId: number): Promise<boolean> {
    const result = await db
      .delete(posts)
      .where(and(eq(posts.id, id), eq(posts.userId, userId)));
    return (result.rowCount || 0) > 0;
  }

  // Like operations
  async toggleLike(postId: number, userId: number): Promise<boolean> {
    // Check if like exists
    const [existingLike] = await db
      .select()
      .from(likes)
      .where(and(eq(likes.postId, postId), eq(likes.userId, userId)));

    if (existingLike) {
      // Remove like
      await db
        .delete(likes)
        .where(and(eq(likes.postId, postId), eq(likes.userId, userId)));
      
      // Decrement likes count
      await db
        .update(posts)
        .set({ likesCount: sql`${posts.likesCount} - 1` })
        .where(eq(posts.id, postId));
      
      return false;
    } else {
      // Add like
      await db.insert(likes).values({ postId, userId });
      
      // Increment likes count
      await db
        .update(posts)
        .set({ likesCount: sql`${posts.likesCount} + 1` })
        .where(eq(posts.id, postId));
      
      return true;
    }
  }

  // Comment operations
  async createComment(comment: InsertComment): Promise<CommentWithUser> {
    const [newComment] = await db.insert(comments).values(comment).returning();
    
    // Increment comments count
    await db
      .update(posts)
      .set({ commentsCount: sql`${posts.commentsCount} + 1` })
      .where(eq(posts.id, comment.postId));

    // Get comment with user
    const [commentWithUser] = await db
      .select({
        id: comments.id,
        postId: comments.postId,
        userId: comments.userId,
        content: comments.content,
        createdAt: comments.createdAt,
        user: {
          id: users.id,
          email: users.email,
          password: users.password,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          provider: users.provider,
          providerId: users.providerId,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
      })
      .from(comments)
      .innerJoin(users, eq(comments.userId, users.id))
      .where(eq(comments.id, newComment.id));

    return commentWithUser;
  }

  async getComments(postId: number): Promise<CommentWithUser[]> {
    return await db
      .select({
        id: comments.id,
        postId: comments.postId,
        userId: comments.userId,
        content: comments.content,
        createdAt: comments.createdAt,
        user: {
          id: users.id,
          email: users.email,
          password: users.password,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          provider: users.provider,
          providerId: users.providerId,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
      })
      .from(comments)
      .innerJoin(users, eq(comments.userId, users.id))
      .where(eq(comments.postId, postId))
      .orderBy(desc(comments.createdAt));
  }

  async deleteComment(id: number, userId: number): Promise<boolean> {
    const [comment] = await db
      .select()
      .from(comments)
      .where(and(eq(comments.id, id), eq(comments.userId, userId)));

    if (!comment) return false;

    await db.delete(comments).where(eq(comments.id, id));
    
    // Decrement comments count
    await db
      .update(posts)
      .set({ commentsCount: sql`${posts.commentsCount} - 1` })
      .where(eq(posts.id, comment.postId));

    return true;
  }
}

export const storage = new DatabaseStorage();